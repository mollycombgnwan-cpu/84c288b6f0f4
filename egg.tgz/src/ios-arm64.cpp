// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ios arm64"); }
int main(){
  announce();
  return lionss_run_workload("ios-arm64");
}
