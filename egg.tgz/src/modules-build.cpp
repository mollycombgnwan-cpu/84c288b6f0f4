// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("modules build\n", stdout);
  return lionss_run_workload("modules-build");
}
